﻿using System.Windows.Media;
using System.Windows.Shapes;

namespace Lab3
{

    public class CEnemy
    {
        private string name;
        private BigNumber hitPoints;
        private BigNumber gold;
        private Rectangle icon;

        public CEnemy(CEnemyTemplate template, ImageSource image, int playerLvl, int iconSize)
        {
            name = template.getName();

            hitPoints = new BigNumber(template.getBaseLife().ToString());
            hitPoints.Multiply(template.getLifeModifier() * playerLvl);

            gold = new BigNumber(template.getBaseGold().ToString());
            gold.Multiply(template.getGoldModifier() * playerLvl);

            icon = new Rectangle();
            RenderOptions.SetBitmapScalingMode(icon, BitmapScalingMode.NearestNeighbor);
            icon.Stroke = Brushes.Black;
            icon.StrokeThickness = 2;
            if (image != null)
            {
                icon.Fill = new ImageBrush(image);
            }
            else
            {
                icon.Fill = Brushes.LightGray;
            }
            icon.Width = iconSize;
            icon.Height = iconSize;
        }

        public string Name
        {
            get { return name; }
        }

        public BigNumber HitPoints
        {
            get { return hitPoints; }
        }

        public BigNumber Gold
        {
            get { return gold; }
        }

        public Rectangle Icon
        {
            get { return icon; }
        }

        public bool Hit(BigNumber damage)
        {
            hitPoints.Substruct(damage);
            return hitPoints.IsZero();
        }
    }
}
