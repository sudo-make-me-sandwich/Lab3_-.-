﻿using System.Collections.Generic;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace Lab3
{

    public class CEnemyTemplateList
    {

        private List<CEnemyTemplate> enemies;

        private JsonSerializerOptions jsonOptions = new JsonSerializerOptions()
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };

        public CEnemyTemplateList()
        {
            enemies = new List<CEnemyTemplate>();
        }

        public void Add(CEnemyTemplate enemy)
        {
            enemies.Add(enemy);
        }

        public void RemoveAt(int index)
        {
            if (index >= 0 && index < enemies.Count)
            {
                enemies.RemoveAt(index);
            }
        }

        public int getCount()
        {
            return enemies.Count;
        }

        public CEnemyTemplate getEnemy(int index)
        {
            return enemies[index];
        }

        public void normalizeChances()
        {
            double sum = 0;
            for (int i = 0; i < enemies.Count; i++)
            {
                sum += enemies[i].SpawnChance;
            }
            if (sum <= 0)
            {
                return;
            }
            for (int i = 0; i < enemies.Count; i++)
            {
                enemies[i].SpawnChance /= sum;
            }
        }

        public CEnemyTemplate findByChance(double chance)
        {
            double sum = 0;
            for (int i = 0; i < enemies.Count; i++)
            {
                sum += enemies[i].SpawnChance;
                if (sum >= chance)
                {
                    return enemies[i];
                }
            }
            return null;
        }

        public void Save(string path)
        {

            string jsonString = JsonSerializer.Serialize(enemies, jsonOptions);

            File.WriteAllText(path, jsonString);
        }

        public void Load(string path)
        {

            string jsonFromFile = File.ReadAllText(path);
            enemies.Clear();

            JsonDocument doc = JsonDocument.Parse(jsonFromFile);

            foreach (JsonElement element in doc.RootElement.EnumerateArray())
            {
                string name = element.GetProperty("name").GetString();
                string iconName = element.GetProperty("iconName").GetString();
                int baseLife = element.GetProperty("baseLife").GetInt32();
                double lifeModifier = element.GetProperty("lifeModifier").GetDouble();
                int baseGold = element.GetProperty("baseGold").GetInt32();
                double goldModifier = element.GetProperty("goldModifier").GetDouble();
                double spawnChance = element.GetProperty("spawnChance").GetDouble();

                CEnemyTemplate enemy = new CEnemyTemplate(name, iconName, baseLife,
                                                          lifeModifier, baseGold,
                                                          goldModifier, spawnChance);

                enemies.Add(enemy);
            }
        }
    }
}
