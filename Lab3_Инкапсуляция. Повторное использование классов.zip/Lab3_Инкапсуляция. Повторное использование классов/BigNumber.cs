﻿using System;

namespace Lab3
{

    public class BigNumber
    {

        private int[] number;

        private const int Base = 1000;

        public BigNumber(string number)
        {
            string s = number.Replace(" ", "").Replace(",", "");
            if (s == "")
            {
                s = "0";
            }
            int len = (s.Length + 2) / 3;
            this.number = new int[len];
            for (int i = 0; i < len; i++)
            {
                int end = s.Length - i * 3;
                int start = end - 3;
                if (start < 0)
                {
                    start = 0;
                }
                this.number[i] = int.Parse(s.Substring(start, end - start));
            }
            Trim();
        }

        private BigNumber(int[] digits)
        {
            number = (int[])digits.Clone();
            Trim();
        }

        public BigNumber getBigNumber()
        {
            return new BigNumber(number);
        }

        public string getStringNumber()
        {
            string s = number[number.Length - 1].ToString();
            for (int i = number.Length - 2; i >= 0; i--)
            {
                s += number[i].ToString("D3");
            }
            return s;
        }

        private void Trim()
        {
            int len = number.Length;
            while (len > 1 && number[len - 1] == 0)
            {
                len--;
            }
            if (len != number.Length)
            {
                int[] cut = new int[len];
                for (int i = 0; i < len; i++)
                {
                    cut[i] = number[i];
                }
                number = cut;
            }
        }

        private void AppendDigit(int digit)
        {
            int[] grown = new int[number.Length + 1];
            for (int i = 0; i < number.Length; i++)
            {
                grown[i] = number[i];
            }
            grown[number.Length] = digit;
            number = grown;
        }

        public void Add(BigNumber bnum)
        {
            int n = Math.Max(number.Length, bnum.number.Length) + 1;
            int[] res = new int[n];
            int carry = 0;
            for (int i = 0; i < n; i++)
            {
                int a = i < number.Length ? number[i] : 0;
                int b = i < bnum.number.Length ? bnum.number[i] : 0;
                int sum = a + b + carry;
                res[i] = sum % Base;
                carry = sum / Base;
            }
            number = res;
            Trim();
        }

        public void Substruct(BigNumber bnum)
        {
            if (CompareTo(bnum) < 0)
            {
                number = new int[] { 0 };
                return;
            }
            int[] res = new int[number.Length];
            int borrow = 0;
            for (int i = 0; i < number.Length; i++)
            {
                int a = number[i] - borrow;
                int b = i < bnum.number.Length ? bnum.number[i] : 0;
                if (a < b)
                {
                    a += Base;
                    borrow = 1;
                }
                else
                {
                    borrow = 0;
                }
                res[i] = a - b;
            }
            number = res;
            Trim();
        }

        public void Multiply(double num)
        {
            long m = (long)Math.Round(num * 10000);
            if (m == 0)
            {
                number = new int[] { 0 };
                return;
            }

            long carry = 0;
            for (int i = 0; i < number.Length; i++)
            {
                long val = number[i] * m + carry;
                number[i] = (int)(val % Base);
                carry = val / Base;
            }
            while (carry > 0)
            {
                AppendDigit((int)(carry % Base));
                carry /= Base;
            }

            Add(new BigNumber("5000"));
            Divide(10);
            Divide(10);
            Divide(10);
            Divide(10);
        }

        public void Divide(double num)
        {
            double rem = 0;
            for (int i = number.Length - 1; i >= 0; i--)
            {
                double cur = number[i] + rem * Base;
                double q = Math.Floor(cur / num);
                number[i] = (int)q;
                rem = cur - q * num;
            }
            Trim();
        }

        public int CompareTo(BigNumber bnum)
        {
            if (number.Length != bnum.number.Length)
            {
                return number.Length > bnum.number.Length ? 1 : -1;
            }
            for (int i = number.Length - 1; i >= 0; i--)
            {
                if (number[i] != bnum.number[i])
                {
                    return number[i] > bnum.number[i] ? 1 : -1;
                }
            }
            return 0;
        }

        public bool MoreOrEqual(BigNumber bnum)
        {
            return CompareTo(bnum) >= 0;
        }

        public bool IsZero()
        {
            return number.Length == 1 && number[0] == 0;
        }
    }
}
