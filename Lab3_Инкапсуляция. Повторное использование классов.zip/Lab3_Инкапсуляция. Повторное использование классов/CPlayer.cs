﻿namespace Lab3
{

    public class CPlayer
    {

        private int lvl;

        private BigNumber gold;

        private BigNumber damage;
        private double damageModifier;

        private BigNumber upgradeCost;
        private double upgradeModifier;

        public CPlayer(BigNumber gold, BigNumber damage, double damageModifier,
                       BigNumber upgradeCost, double upgradeModifier)
        {
            lvl = 1;
            this.gold = gold;
            this.damage = damage;
            this.damageModifier = damageModifier;
            this.upgradeCost = upgradeCost;
            this.upgradeModifier = upgradeModifier;
        }

        public int Lvl
        {
            get { return lvl; }
            private set { lvl = value; }
        }

        public BigNumber Gold
        {
            get { return gold; }
            private set { gold = value; }
        }

        public BigNumber Damage
        {
            get { return damage; }
            private set { damage = value; }
        }

        public double DamageModifier
        {
            get { return damageModifier; }
            private set { damageModifier = value; }
        }

        public BigNumber UpgradeCost
        {
            get { return upgradeCost; }
            private set { upgradeCost = value; }
        }

        public double UpgradeModifier
        {
            get { return upgradeModifier; }
            private set { upgradeModifier = value; }
        }

        public bool gainGold(BigNumber gold)
        {
            this.gold.Add(gold);
            return true;
        }

        public bool upgrade()
        {
            if (!gold.MoreOrEqual(upgradeCost))
            {
                return false;
            }
            gold.Substruct(upgradeCost);
            damage.Multiply(damageModifier);
            upgradeCost.Multiply(upgradeModifier * lvl);
            Lvl += 1;
            return true;
        }
    }
}
