﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab3
{

    public class CIcon
    {

        private string name;

        private Point position;

        private int width;
        private int height;

        private Rectangle icon;

        public CIcon(int iconWidth, int iconHeight, string imagePath, Point pos)
        {
            position = pos;
            width = iconWidth;
            height = iconHeight;
            name = System.IO.Path.GetFileNameWithoutExtension(imagePath);

            icon = new Rectangle();

            RenderOptions.SetBitmapScalingMode(icon, BitmapScalingMode.NearestNeighbor);

            icon.Stroke = Brushes.Black;
            icon.StrokeThickness = 1;
            ImageBrush ib = new ImageBrush();

            ib.AlignmentX = AlignmentX.Left;
            ib.AlignmentY = AlignmentY.Top;

            ib.ImageSource = new BitmapImage(new Uri(imagePath, UriKind.Absolute));
            icon.RenderTransform = new TranslateTransform(position.X, position.Y);
            icon.Fill = ib;

            icon.HorizontalAlignment = HorizontalAlignment.Left;
            icon.VerticalAlignment = VerticalAlignment.Center;

            icon.Height = iconHeight;
            icon.Width = iconWidth;
        }

        public string getName()
        {
            return name;
        }

        public Rectangle getIcon()
        {
            return icon;
        }

        public Point getPosition()
        {
            return position;
        }

        public int getWidth()
        {
            return width;
        }

        public int getHeight()
        {
            return height;
        }

        public ImageSource getImageSource()
        {
            return ((ImageBrush)icon.Fill).ImageSource;
        }

        public bool contains(Point p)
        {
            return p.X >= position.X && p.X <= position.X + width &&
                   p.Y >= position.Y && p.Y <= position.Y + height;
        }

        public void setSelected(bool selected)
        {
            if (selected)
            {
                icon.Stroke = Brushes.Red;
                icon.StrokeThickness = 3;
            }
            else
            {
                icon.Stroke = Brushes.Black;
                icon.StrokeThickness = 1;
            }
        }
    }
}
