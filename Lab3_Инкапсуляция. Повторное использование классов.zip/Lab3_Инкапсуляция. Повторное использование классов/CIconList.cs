﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Lab3
{

    public class CIconList
    {

        private List<CIcon> icons;

        private int iconWidth;
        private int iconHeight;

        private Canvas canvas;

        public CIconList(Canvas canvas, int iconWidth, int iconHeight)
        {
            icons = new List<CIcon>();
            this.canvas = canvas;
            this.iconWidth = iconWidth;
            this.iconHeight = iconHeight;
        }

        public void Load(string path)
        {

            string folder =
                System.IO.Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName) + path;

            if (!Directory.Exists(folder))
            {
                return;
            }

            string filter = "*.png";

            string[] files = Directory.GetFiles(folder, filter);

            int perRow = (int)(canvas.Width / (iconWidth + 10));
            if (perRow < 1)
            {
                perRow = 1;
            }

            int rows = (files.Length + perRow - 1) / perRow;
            if (rows < 1)
            {
                rows = 1;
            }

            int gridWidth = perRow * iconWidth + (perRow - 1) * 10;
            int gridHeight = rows * iconHeight + (rows - 1) * 10;

            double offX = (canvas.Width - gridWidth) / 2;
            double offY = (canvas.Height - gridHeight) / 2;
            if (offX < 5)
            {
                offX = 5;
            }
            if (offY < 5)
            {
                offY = 5;
            }
            int index = 0;
            foreach (string file in files)
            {

                int col = index % perRow;
                int row = index / perRow;
                Point pos = new Point(offX + col * (iconWidth + 10), offY + row * (iconHeight + 10));

                CIcon icon = new CIcon(iconWidth, iconHeight, file, pos);
                icons.Add(icon);

                canvas.Children.Add(icon.getIcon());
                index++;
            }
        }

        public CIcon getIconByName(string name)
        {
            foreach (CIcon icon in icons)
            {
                if (icon.getName() == name)
                {
                    return icon;
                }
            }
            return null;
        }

        public CIcon getIconAt(Point p)
        {
            foreach (CIcon icon in icons)
            {
                if (icon.contains(p))
                {
                    return icon;
                }
            }
            return null;
        }

        public void select(string name)
        {
            foreach (CIcon icon in icons)
            {
                icon.setSelected(icon.getName() == name);
            }
        }

        public int getCount()
        {
            return icons.Count;
        }
    }
}
