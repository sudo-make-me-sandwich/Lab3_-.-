﻿using System;
using System.IO;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace Lab3
{
    public partial class MainWindow : Window
    {

        private CEnemyTemplateList templates;

        private CIconList iconList;

        private CPlayer player;
        private CEnemy enemy;

        private CEnemyTemplate currentTemplate;

        private Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();

            player = new CPlayer(new BigNumber("0"), new BigNumber("1"), 1.5,
                                 new BigNumber("10"), 1.6);

            iconList = new CIconList(iconStorageCanvas, 64, 64);
            iconList.Load("\\icons");

            templates = new CEnemyTemplateList();
            string path = System.IO.Path.GetDirectoryName(
                Process.GetCurrentProcess().MainModule.FileName) + "\\enemies.json";
            if (File.Exists(path))
            {
                templates.Load(path);
                SetStatus("Шаблоны противников загружены из файла enemies.json: "
                          + templates.getCount() + " шт.");
            }
            else
            {

                templates.Add(new CEnemyTemplate("Bird", "enemy_bird_warrior",
                                  10, 1.2, 5, 1.2, 0.5));
                templates.Add(new CEnemyTemplate("Knight", "enemy_knight_blades",
                                  20, 1.3, 10, 1.3, 0.5));
                SetStatus("Файл enemies.json не найден, взяты шаблоны по умолчанию.");
            }

            templates.normalizeChances();

            SpawnRandom();
        }

        private void SpawnRandom()
        {
            if (templates.getCount() == 0)
            {
                return;
            }
            CEnemyTemplate template = templates.findByChance(rnd.NextDouble());
            if (template == null)
            {
                template = templates.getEnemy(0);
            }
            SpawnFromTemplate(template);
        }

        private void SpawnFromTemplate(CEnemyTemplate template)
        {
            currentTemplate = template;
            CIcon icon = iconList.getIconByName(template.getIconName());
            ImageSource image = icon != null ? icon.getImageSource() : null;
            enemy = new CEnemy(template, image, player.Lvl, 160);

            enemy.Icon.MouseLeftButtonUp += EnemyIcon_Click;
            enemyCanvas.Children.Clear();
            enemyCanvas.Children.Add(enemy.Icon);
            UpdateUI();
        }

        private void EnemyIcon_Click(object sender, MouseButtonEventArgs e)
        {
            if (enemy == null)
            {
                return;
            }
            bool dead = enemy.Hit(player.Damage);
            if (dead)
            {

                string deadName = enemy.Name;
                string deadGold = enemy.Gold.getStringNumber();
                player.gainGold(enemy.Gold);
                SetStatus("Победа над противником «" + deadName + "»! Получено золота: "
                          + deadGold + ".");

                SpawnRandom();
                SetStatus("Победа над противником «" + deadName + "»! Получено золота: "
                          + deadGold + ". Появился следующий противник: " + enemy.Name + ".");
            }
            else
            {
                SetStatus("Противнику «" + enemy.Name + "» нанесён урон "
                          + player.Damage.getStringNumber() + ".");
                UpdateUI();
            }
        }

        private void btnRepeat_Click(object sender, RoutedEventArgs e)
        {
            if (currentTemplate != null)
            {
                SpawnFromTemplate(currentTemplate);
                SetStatus("Противник «" + currentTemplate.getName() + "» появился снова.");
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            SpawnRandom();
            SetStatus("Выполнен переход к следующему противнику без награды.");
        }

        private void btnUpgrade_Click(object sender, RoutedEventArgs e)
        {
            if (player.upgrade())
            {
                SetStatus("Улучшение куплено! Урон и уровень возросли, цена следующего улучшения увеличилась.");
            }
            else
            {
                SetStatus("Не хватает золота на улучшение.");
            }
            UpdateUI();
        }

        private void UpdateUI()
        {
            if (enemy != null)
            {
                tbEnemyName.Text = enemy.Name;
                tbEnemyHp.Text = enemy.HitPoints.getStringNumber();
                tbEnemyGold.Text = enemy.Gold.getStringNumber();
            }
            tbLevel.Text = player.Lvl.ToString();
            tbPlayerGold.Text = player.Gold.getStringNumber();
            tbPlayerDamage.Text = player.Damage.getStringNumber();
            tbUpgradeCost.Text = player.UpgradeCost.getStringNumber();

            btnUpgrade.IsEnabled = player.Gold.MoreOrEqual(player.UpgradeCost);
        }

        private void SetStatus(string text)
        {
            tbStatus.Text = text;
        }
    }
}
